-- ═══════════════════════════════════════════
-- NAJDA AUTO — Supabase Schema
-- A Planet T&L SUARL × BRCC-AUTO
-- ═══════════════════════════════════════════

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── USERS (company admins & mechanics) ──
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  phone TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('company', 'mechanic')),
  name TEXT NOT NULL,
  avatar TEXT DEFAULT '👤',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── SERVICE REQUESTS ──
CREATE TABLE IF NOT EXISTS requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_name TEXT NOT NULL,
  client_phone TEXT NOT NULL,
  car_type TEXT NOT NULL,
  plate TEXT,
  problem TEXT NOT NULL,
  service_tier TEXT NOT NULL CHECK (service_tier IN ('eco', 'premium', 'vip')),
  lat DECIMAL(10,8),
  lng DECIMAL(11,8),
  location_text TEXT,
  photos TEXT[], -- array of photo URLs
  status TEXT NOT NULL DEFAULT 'new'
    CHECK (status IN ('new','quoted','payment_pending','payment_received','assigned','active','done','cancelled')),
  assigned_mechanic_id UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── QUOTES ──
CREATE TABLE IF NOT EXISTS quotes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  request_id UUID NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
  diagnosis TEXT,
  labor INTEGER NOT NULL DEFAULT 0,
  parts INTEGER NOT NULL DEFAULT 0,
  towing INTEGER NOT NULL DEFAULT 0,
  total INTEGER GENERATED ALWAYS AS (labor + parts + towing) STORED,
  deposit INTEGER GENERATED ALWAYS AS (ROUND((labor + parts + towing) * 0.1)) STORED,
  service_type TEXT CHECK (service_type IN ('onsite','tow')),
  mechanic_id UUID REFERENCES users(id),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending','accepted','rejected')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── PAYMENTS ──
CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  request_id UUID NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
  quote_id UUID REFERENCES quotes(id),
  amount INTEGER NOT NULL,
  method TEXT NOT NULL CHECK (method IN ('bankily','masrivi','bim','sedad')),
  type TEXT NOT NULL CHECK (type IN ('deposit','final')),
  receipt_url TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending','verified','rejected')),
  verified_by UUID REFERENCES users(id),
  verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── NOTIFICATIONS ──
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  for_role TEXT NOT NULL CHECK (for_role IN ('company','mechanic','client')),
  for_user_id UUID REFERENCES users(id),
  request_id UUID REFERENCES requests(id),
  icon TEXT DEFAULT '🔔',
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── MECHANIC LOCATIONS ──
CREATE TABLE IF NOT EXISTS mechanic_locations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  mechanic_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lat DECIMAL(10,8) NOT NULL,
  lng DECIMAL(11,8) NOT NULL,
  is_available BOOLEAN DEFAULT true,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ═══════════════════════════════════════════
-- ROW LEVEL SECURITY
-- ═══════════════════════════════════════════
ALTER TABLE users               ENABLE ROW LEVEL SECURITY;
ALTER TABLE requests            ENABLE ROW LEVEL SECURITY;
ALTER TABLE quotes              ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments            ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications       ENABLE ROW LEVEL SECURITY;
ALTER TABLE mechanic_locations  ENABLE ROW LEVEL SECURITY;

-- Allow all for now (tighten after testing)
CREATE POLICY "allow_all_users"              ON users              FOR ALL USING (true);
CREATE POLICY "allow_all_requests"           ON requests           FOR ALL USING (true);
CREATE POLICY "allow_all_quotes"             ON quotes             FOR ALL USING (true);
CREATE POLICY "allow_all_payments"           ON payments           FOR ALL USING (true);
CREATE POLICY "allow_all_notifications"      ON notifications      FOR ALL USING (true);
CREATE POLICY "allow_all_mechanic_locations" ON mechanic_locations FOR ALL USING (true);

-- ═══════════════════════════════════════════
-- REALTIME (enable for live updates)
-- ═══════════════════════════════════════════
ALTER PUBLICATION supabase_realtime ADD TABLE requests;
ALTER PUBLICATION supabase_realtime ADD TABLE quotes;
ALTER PUBLICATION supabase_realtime ADD TABLE payments;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE mechanic_locations;

-- ═══════════════════════════════════════════
-- TRIGGER: updated_at
-- ═══════════════════════════════════════════
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_requests_updated_at
  BEFORE UPDATE ON requests
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ═══════════════════════════════════════════
-- SEED: Demo users (change passwords in production!)
-- ═══════════════════════════════════════════
INSERT INTO users (phone, password_hash, role, name, avatar) VALUES
  ('+222 00 00 00 01', 'admin123', 'company',  'محمد النعمان',      '🏢'),
  ('+222 00 00 00 02', 'mech456',  'mechanic', 'إبراهيم ولد الشيخ', '👷'),
  ('+222 00 00 00 03', 'mech789',  'mechanic', 'محمد لمين',         '👷')
ON CONFLICT (phone) DO NOTHING;
